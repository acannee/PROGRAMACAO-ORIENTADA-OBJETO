package Exercicio1;

public class carro {
    
	private String modelo;
	private short ano;
	private String fabricante;
	private String chassi;
	private byte numPortas;
	private String car;
	private String cadFip;
	private double precoVenda;
	
}
