package Exercicio1;

public class cliente {

	private String nome;
	private String CPF;
	private String RG;
	private String CNPJ;
	private boolean tipoCliente;
	private String telefone;
	private String email;
	
}
