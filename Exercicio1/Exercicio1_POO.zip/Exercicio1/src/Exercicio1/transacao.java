package Exercicio1;

import java.util.Date;

public class transacao {

	private Date dataTransacao;
	private byte tipoTransacao;
	private double valorTransacao;
	private byte formaPag;
	

}
