module Exercicio3LP {
	requires java.desktop;
}