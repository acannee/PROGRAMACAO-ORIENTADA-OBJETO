package Carnaval;

public class Camarote {

}
