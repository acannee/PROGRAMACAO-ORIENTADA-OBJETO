package Carnaval;

public class Menu {

	public static void main(String[] args) {
		


	}

}


///criar carnaval classe ingresso 
//private valor 

//n�o tem set e get na quest�o 1 do exercicio 3 
 
//fazer no main  (menu)
//ingresso normal
//System.out.print(digite)
//vip
//System.out.print(digite)
//camarote
//System.out.print(digite)
//sair 
//System.out.print(digite)

	
