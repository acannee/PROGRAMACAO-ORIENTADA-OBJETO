package funcionario;

public class FPadrao {

}
