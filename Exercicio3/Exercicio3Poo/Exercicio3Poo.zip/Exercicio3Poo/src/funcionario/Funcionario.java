package funcionario;

public class Funcionario {

}
