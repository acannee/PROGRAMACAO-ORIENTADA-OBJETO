package Questao1;

public class Ingresso {
	
	private double valor;
	
	public Ingresso(double valor) {
		super();
		this.valor = valor;
	}
	
	public double getValor() {
		return valor;
	}

	public void setValor(float valor) {
		this.valor = valor;
	}
	
	
}