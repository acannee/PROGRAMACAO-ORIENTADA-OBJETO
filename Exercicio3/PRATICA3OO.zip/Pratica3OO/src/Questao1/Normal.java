package Questao1;

public class Normal extends Ingresso{

	public Normal(double valor) {
		super(valor);
	}
	
	public void valordoIngresso() {
		System.out.println("O valor do Ingresso Normal �: "+this.getValor());
	}

}