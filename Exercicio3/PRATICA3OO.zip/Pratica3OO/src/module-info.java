module Pratica3OO {
}