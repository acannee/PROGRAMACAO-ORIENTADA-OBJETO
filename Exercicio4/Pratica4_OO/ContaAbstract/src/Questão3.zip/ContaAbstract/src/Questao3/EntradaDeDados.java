package Questao3;

import java.util.Scanner;

public class EntradaDeDados  {

	public static void main(String[] args) {
		
		Scanner ler=new Scanner(System.in);
		
		System.out.println("Entre com o nome do funcion�rio: ");
		String nome=ler.next();
	}

}