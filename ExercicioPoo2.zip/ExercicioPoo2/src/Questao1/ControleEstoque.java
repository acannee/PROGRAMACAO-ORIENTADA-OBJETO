package Questao1;

import java.util.Scanner;

public class ControleEstoque {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner ler=new Scanner(System.in);
		
		System.out.print("Digite o nome do produto: ");
        String nome = ler.nextLine();
        System.out.print("Digite a quantidade minima do produto: ");
        int minima = ler.nextInt();
        System.out.print("Digite a quantidade atual do produto: ");
        int atual = ler.nextInt();
        
        Estoque produto = new Estoque(nome, atual, minima);

        System.out.print("Digite a quantidade que deseja dar baixa no estoque: ");
        produto.darBaixa(ler.nextInt());
		
        System.out.println();
        System.out.printf(produto.mostrarEstoque());
        System.out.println();

        if (produto.precisaRepor() == true){
            System.out.println("O produto precisa de reposi��o");
            
        }
         else {
          	System.out.println("O produto n�o precisa de reposi��o");
         
        }

}
}
