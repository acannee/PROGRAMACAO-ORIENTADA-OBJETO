package Questao1;

public interface publicacao {
    abstract String buscarTitulo(String titulo);
    abstract void visualizarDetalhes();
}