package Questao2;

public class DistribuicaoAlimento {

}
