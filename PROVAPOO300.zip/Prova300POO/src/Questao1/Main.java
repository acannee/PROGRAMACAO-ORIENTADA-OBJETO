package Questao1;

public class Main {

	public static void main(String[] args) {
	
			Pessoa p1 = new Pessoa("Anne", 1.65f, 65);
			p1.Andar();
			p1.Correr();
			
			Aluno a1 = new Aluno(1234, "Josephino", 1.55f, 60);
			a1.Andar();
			a1.Correr();
		}

}
