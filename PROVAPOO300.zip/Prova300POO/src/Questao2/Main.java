package Questao2;

import java.util.Scanner; 

public class Main {

	public static void main(String[] args) {
		Scanner ler = new Scanner (System.in);
		
		System.out.println("-----------MENU-----------");
		System.out.println("Escola uma op��o:");
		System.out.println("(1) Cadastrar Utilit�rio");
		System.out.println("(2) Cadastrar Motocicleta");
		System.out.println("(3) Cadastrar Van");
		System.out.println("(4) Cadastrar Caminh�o");
		System.out.println("(5) Sair");
		System.out.println("----------------------");
	
		
	}

}
