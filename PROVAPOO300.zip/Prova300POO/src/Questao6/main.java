package Questao6;

public class main {

	public static void main(String[] args) {
		
		RedeSocial p1 = new RedeSocial ("Anne","newton@newton.com.br","3199999-9999","@acannee");
		RedeSocial p2 = new RedeSocial ("Estopa","newton@newton.com.br","3199999-9999","@estopa");
		
		p1.mostraDados();
		p2.mostraDados();
	}

}
