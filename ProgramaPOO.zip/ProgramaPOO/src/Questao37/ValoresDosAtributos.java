package Questao37;

public class ValoresDosAtributos {

	public static void main(String[] args) {
		Funcionario[] funcionarios = new Funcionario[100];


	}

}
