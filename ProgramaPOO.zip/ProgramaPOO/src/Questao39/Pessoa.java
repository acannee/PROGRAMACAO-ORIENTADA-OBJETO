package Questao39;

public class Pessoa {

}
