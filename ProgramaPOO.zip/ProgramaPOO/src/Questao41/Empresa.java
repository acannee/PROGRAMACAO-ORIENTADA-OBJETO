package Questao41;

public class Empresa {

}
