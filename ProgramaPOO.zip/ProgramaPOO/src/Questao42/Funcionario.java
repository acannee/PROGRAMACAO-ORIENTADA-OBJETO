package Questao42;

public class Funcionario {

}
