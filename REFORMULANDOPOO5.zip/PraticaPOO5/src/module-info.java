module PraticaPOO5 {
}